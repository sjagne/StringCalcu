# Internship assignment for [Incubyte](https://incubyte.co)

Take the technical assessment described [here](https://osherove.com/tdd-kata-1)

Please code this in Java (not .NET) using TDD. You will need to commit your code to Git and send us a link to the repo. Make sure to commit your repo multiple times so that it highlights each step of TDD separately, and we can see how your code evolves.